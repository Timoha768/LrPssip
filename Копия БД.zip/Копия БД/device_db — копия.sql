-- ============================================================
-- БД для сайта «Девайс» (device) — интернет-магазин гаджетов
-- MySQL 5.7+ / MariaDB 10.2+
-- Кодировка: utf8mb4
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ------------------------------------------------------------
-- Создание базы данных
-- ------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS `device_db`
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE `device_db`;

-- ------------------------------------------------------------
-- Категории каталога (меню и фильтры)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL COMMENT 'Название (Виртуальная реальность, Моноподы для селфи и т.д.)',
  `slug` VARCHAR(100) NOT NULL,
  `sort_order` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Пользователи (вход по email/пароль)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(255) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL COMMENT 'password_hash() / PASSWORD_DEFAULT',
  `role` ENUM('user','admin') NOT NULL DEFAULT 'user' COMMENT 'user — обычный пользователь, admin — доступ в админ-панель',
  `name` VARCHAR(120) DEFAULT NULL COMMENT 'Имя для отображения',
  `phone` VARCHAR(30) DEFAULT NULL,
  `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Товары
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_id` INT UNSIGNED NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `price` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Цена в рублях',
  `image` VARCHAR(255) DEFAULT NULL COMMENT 'Путь к изображению (img/item-1.jpg)',
  `is_new` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'Метка «Новинка»',
  `has_bluetooth` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'Есть Bluetooth (для фильтра)',
  `is_featured` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'Показывать в слайдере на главной',
  `sort_order` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `category_id` (`category_id`),
  KEY `price` (`price`),
  KEY `is_featured` (`is_featured`),
  CONSTRAINT `products_category_fk` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Отзывы к товарам
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `product_reviews`;
CREATE TABLE `product_reviews` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id` INT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL,
  `rating` TINYINT UNSIGNED NOT NULL DEFAULT 5,
  `comment` TEXT NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `product_reviews_product_fk` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `product_reviews_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Цвета товара (фильтр в каталоге: черный, белый, синий, красный, розовый)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `product_colors`;
CREATE TABLE `product_colors` (
  `product_id` INT UNSIGNED NOT NULL,
  `color` VARCHAR(30) NOT NULL COMMENT 'black, white, blue, red, pink',
  PRIMARY KEY (`product_id`, `color`),
  CONSTRAINT `product_colors_product_fk` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Бренды (главная: DJI, SpGadgets, GoPro, VIVE)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `brands`;
CREATE TABLE `brands` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(80) NOT NULL,
  `image` VARCHAR(255) DEFAULT NULL COMMENT 'img/dji-gray.png и т.д.',
  `url` VARCHAR(255) DEFAULT NULL,
  `sort_order` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Заказы (форма «Сделать заказ»: имя, телефон, комментарий)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED DEFAULT NULL COMMENT 'NULL если гость',
  `name` VARCHAR(120) NOT NULL,
  `phone` VARCHAR(30) NOT NULL,
  `address` VARCHAR(255) DEFAULT NULL,
  `comment` TEXT DEFAULT NULL,
  `status` ENUM('new','confirmed','shipped','delivered','cancelled') NOT NULL DEFAULT 'new',
  `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `orders_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Позиции в заказе
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` INT UNSIGNED NOT NULL,
  `product_id` INT UNSIGNED NOT NULL,
  `quantity` INT UNSIGNED NOT NULL DEFAULT 1,
  `price` DECIMAL(10,2) NOT NULL COMMENT 'Цена на момент заказа',
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `order_items_order_fk` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `order_items_product_fk` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Корзина (привязка к пользователю)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `product_id` INT UNSIGNED NOT NULL,
  `quantity` INT UNSIGNED NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_product` (`user_id`, `product_id`),
  CONSTRAINT `cart_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cart_product_fk` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Сравнение товаров
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `compare`;
CREATE TABLE `compare` (
  `user_id` INT UNSIGNED NOT NULL,
  `product_id` INT UNSIGNED NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`, `product_id`),
  CONSTRAINT `compare_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `compare_product_fk` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Сообщения «Напишите нам» (форма обратной связи)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `contact_messages`;
CREATE TABLE `contact_messages` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(120) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `read_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Настройки сайта (админ-панель)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `site_settings`;
CREATE TABLE `site_settings` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `setting_key` VARCHAR(100) NOT NULL,
  `setting_value` TEXT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- Начальные данные
-- ============================================================

-- Категории (как в меню сайта)
INSERT INTO `categories` (`name`, `slug`, `sort_order`) VALUES
('Виртуальная реальность', 'virtual-reality', 1),
('Моноподы для селфи', 'selfie-sticks', 2),
('Экшн-камеры', 'action-cameras', 3),
('Фитнес-браслеты', 'fitness-bracelets', 4),
('Умные часы', 'smartwatches', 5),
('Квадрокоптеры', 'quadcopters', 6);

-- Бренды (главная страница)
INSERT INTO `brands` (`name`, `image`, `url`, `sort_order`) VALUES
('DJI', 'img/dji-gray.png', '#', 1),
('SpGadgets', 'img/spgadgets-gray.png', '#', 2),
('GoPro', 'img/gopro-gray.png', '#', 3),
('VIVE', 'img/vive-gray.png', '#', 4);

-- Товары каталога «Моноподы для селфи» (как на странице catalog.html)
INSERT INTO `products` (`category_id`, `name`, `slug`, `description`, `price`, `image`, `is_new`, `has_bluetooth`, `is_featured`, `sort_order`) VALUES
(2, 'Любительская селфи-палка', 'selfie-stick-amateur', 'Простая и надёжная палка для селфи.', 500.00, 'img/item-1.jpg', 0, 1, 0, 1),
(2, 'Профессиональная селфи-палка', 'selfie-stick-pro', 'Удобная ручка и крепкий держатель.', 1500.00, 'img/item-2.jpg', 0, 1, 0, 2),
(2, 'Непотопляемая селфи-палка', 'selfie-stick-waterproof', 'Для съёмки в бассейне и на море.', 2500.00, 'img/item-3.jpg', 0, 0, 0, 3),
(2, 'Селфи-палка «Следуй за мной»', 'selfie-stick-follow-me', 'С поддержкой отслеживания лица.', 4900.00, 'img/item-4.jpg', 1, 1, 0, 4);

-- Цвета для товаров (фильтр в каталоге)
INSERT INTO `product_colors` (`product_id`, `color`) VALUES
(1, 'black'), (1, 'blue'), (1, 'red'),
(2, 'black'), (2, 'white'), (2, 'blue'),
(3, 'black'), (3, 'blue'), (3, 'red'),
(4, 'black'), (4, 'red'), (4, 'pink');

-- Товары для слайдера на главной (секция «Товары»)
UPDATE `products` SET `is_featured` = 1, `description` = 'Самая длинная палка для селфи. 8,5 м, 5 кг, карбон.' WHERE `id` = 1;
INSERT INTO `products` (`category_id`, `name`, `slug`, `description`, `price`, `image`, `is_new`, `has_bluetooth`, `is_featured`, `sort_order`) VALUES
(4, 'Фитнес-браслет', 'fitness-bracelet', 'Мотивирующие фитнес-браслеты. Без подзарядки 48 часов.', 0, 'img/slider-2.png', 0, 1, 1, 10),
(6, 'Лазерный квадрокоптер', 'quadcopter-laser', 'Квадрокоптер с лазером. Дальность 800 м, радиус 50 м.', 0, 'img/slider-3.png', 0, 0, 1, 11);
UPDATE `products` SET `image` = 'img/slider-1.png' WHERE `id` = 1;

-- Тестовый администратор (пароль: password — сменить в продакшене)
-- Новый хэш в PHP: echo password_hash('ваш_пароль', PASSWORD_DEFAULT);
INSERT INTO `users` (`email`, `password_hash`, `role`, `name`) VALUES
('admin@timka.local', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'Администратор');

INSERT INTO `site_settings` (`setting_key`, `setting_value`) VALUES
('site_title', 'Девайс'),
('site_phone', '+375 (25) 791-27-28'),
('site_address', 'г. Гродно, ул. Новооктябрьская, 5'),
('site_email', 'info@timka.local'),
('about_text', 'Огромный выбор гаджетов не оставит равнодушным гика, который есть в каждом из нас.')
ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`);

-- ============================================================
-- Конец скрипта
-- ============================================================
-- Импорт: в phpMyAdmin выберите БД или создайте device_db,
-- затем вкладка «Импорт» → выберите этот файл → Выполнить.
-- Либо в консоли MySQL:
--   mysql -u root -p < device_db.sql
-- ============================================================
